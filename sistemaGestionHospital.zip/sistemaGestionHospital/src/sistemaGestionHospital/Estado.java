package sistemaGestionHospital;

public enum Estado {
    PROGRAMADA, REALIZADA, CANCELADA;
}
