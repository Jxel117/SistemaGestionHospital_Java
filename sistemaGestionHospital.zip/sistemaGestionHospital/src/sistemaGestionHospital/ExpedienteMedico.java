package sistemaGestionHospital;

public class ExpedienteMedico {
    private String historialMedico;
    private String diagnostico;
    private String tratamiento;
}
