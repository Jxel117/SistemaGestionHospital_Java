package sistemaGestionHospital;

public class Sistema {
    //Atributos
    private String numeroCitas;
    //Relaciones
    private CitaMedica citaMedica;
}
