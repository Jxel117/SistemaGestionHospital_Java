package sistemaGestionHospital;

public abstract class Persona {
    //Atributos
    private String nombre;
    private String apellido;
    private String dni;
    private String direccion;

    //Metodos
}
