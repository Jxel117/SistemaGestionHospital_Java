package sistemaGestionHospital;

public interface GestionCitas {
        public void programarCita();
        public void cancelarCita();
        public void realizarCitas();
    }
