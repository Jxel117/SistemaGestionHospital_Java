package sistemaGestionHospital;

public class Enfermero extends Persona {
    //Relaciones
    private Doctor[] doctoList;
    private Enfermero[] enfermeroList;
    private Paciente[] pacienteList;
    private CitaMedica[] citaMedicaList;

}
