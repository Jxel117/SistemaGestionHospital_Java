package sistemaGestionHospital;

public enum EspecialidadMedica {
    CARDIOLOGIA,PEDIATRIA, ODONTOLOGIA, DERMATOLOGIA, NUTRICION;
}
